module.exports = {
    url: process.env.DATABASE_URI,
    name: process.env.DATABASE_NAME
}